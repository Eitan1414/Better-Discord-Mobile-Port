# Importation rapide sur GitHub

1. Crée un dépôt vide, par exemple `BDMobileCompat`.
2. Décompresse cette archive.
3. Envoie tous les fichiers à la racine du dépôt, y compris `.github`.
4. Ouvre l'onglet **Actions**.
5. Lance **Build BD Mobile Compat**.
6. Télécharge l'artefact `BDMobileCompat-Revenge`.
7. Pour publier automatiquement le dépôt de plugins, active :
   **Settings → Pages → Source → GitHub Actions**.
8. Dans Revenge, ajoute l'adresse GitHub Pages terminée par `/repo.json`.

Ce projet produit un plugin Revenge Android, pas un APK Discord autonome.
