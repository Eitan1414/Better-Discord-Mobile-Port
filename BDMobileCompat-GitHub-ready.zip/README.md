# BD Mobile Compat

An experimental **BetterDiscord `BdApi` compatibility bridge** for Discord Android running through Revenge.

This is not an official BetterDiscord mobile release and it does not redistribute Discord. It exposes a mobile-oriented `globalThis.BdApi` so selected BetterDiscord-style plugins can be adapted instead of rewritten from zero.

## What works in version 0.1.0

- `BdApi.Data`: scoped save, load and delete
- `BdApi.Logger`: scoped logging
- `BdApi.UI`: Revenge toasts and Android native dialogs
- `BdApi.Patcher`: adapted to Revenge's patcher
- `BdApi.Plugins`: reads and controls Revenge plugins
- `BdApi.Themes`: controls Revenge JSON themes
- `BdApi.Webpack`: best-effort mapping to Discord Mobile Metro modules
- `new BdApi("PluginName")`: scoped Data, Logger, Patcher and Commands
- safe mode and strict unsupported-API mode
- an in-app settings screen

## What cannot work unchanged

Desktop BetterDiscord plugins that depend on these APIs need a mobile rewrite:

- the HTML DOM, `document`, selectors and ReactDOM;
- CSS injection and `.theme.css` files;
- Electron or Node.js APIs;
- desktop Webpack module assumptions;
- desktop context menus and desktop-only Discord components.

Revenge uses React Native and Metro, not Electron, HTML and desktop Webpack.

## Build

Requirements: Node.js 20 or newer and npm.

```bash
npm install
npm test
npm run build
```

Generated repository files:

```text
repo.json
builds/dev.bdmobile.compat/manifest.json
builds/dev.bdmobile.compat/index.js
```

## Build and publish with GitHub Actions

1. Create an empty GitHub repository and upload the contents of this folder.
2. Push to the `main` branch.
3. Open **Actions → Build BD Mobile Compat**.
4. Download the `BDMobileCompat-Revenge` artifact, or enable **Pages → GitHub Actions**.
5. Add the published URL ending in `/repo.json` to Revenge's plugin repositories.
6. Install **BD Mobile Compat** from Revenge and restart Discord.

## Plugin adaptation example

A desktop plugin using scoped BetterDiscord data can often keep code like this:

```js
const api = new BdApi("MyPlugin");
const settings = api.Data.load("settings") ?? {enabled: true};
api.Data.save("settings", settings);
api.UI.showToast("MyPlugin loaded on Android");
```

DOM or CSS code must be replaced by React Native components or a Revenge JSON theme.

## Safety and account notice

Client modifications may conflict with Discord's terms and can break when Discord updates. Use a test account first, keep safe mode available, and never install unreviewed plugins that request tokens or credentials.

## Supplied AppImage

The Linux AppImage was statically inspected. It is BetterDiscord Installer 1.3.0 built with Electron/Svelte, rather than the complete BetterDiscord runtime. Details are in `docs/appimage-analysis.md`. No extracted AppImage code is included here.
