import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";

const code = readFileSync(new URL("../dist/index.js", import.meta.url), "utf8");
const pluginStorage = {};
const toasts = [];
const context = {
    console,
    setTimeout,
    clearTimeout,
    URL,
    fetch: globalThis.fetch,
    Request,
    Response,
    definePlugin: value => value,
    bunny: {
        plugin: {
            createStorage: () => pluginStorage
        },
        api: {
            patcher: {
                before: () => () => true,
                after: () => () => true,
                instead: () => () => true
            },
            commands: {
                registerCommand: () => () => true
            }
        },
        ui: {
            toasts: {showToast: value => toasts.push(value)},
            components: {}
        },
        metro: {
            common: {
                React: {createElement: () => null, useReducer: () => [0, () => {}]},
                ReactNative: {
                    Alert: {alert: () => {}},
                    StyleSheet: {create: value => value}
                }
            },
            filters: {byProps: () => () => false},
            findExports: () => undefined,
            findAllExports: () => []
        },
        plugins: {
            registeredPlugins: new Map(),
            pluginInstances: new Map(),
            isPluginEnabled: () => false
        },
        themes: {themes: {}}
    }
};
context.globalThis = context;
context.window = context;
vm.createContext(context);
vm.runInContext(`${code}\n;globalThis.__plugin = plugin;`, context);

assert.equal(typeof context.__plugin.start, "function");
context.__plugin.start();
assert.equal(typeof context.BdApi, "function");
assert.equal(context.BdApi.mobile, true);
assert.match(context.BdApi.version, /android/);

context.BdApi.Data.save("ExamplePlugin", "enabled", true);
assert.equal(context.BdApi.Data.load("ExamplePlugin", "enabled"), true);
const scoped = new context.BdApi("ExamplePlugin");
scoped.Data.save("count", 3);
assert.equal(scoped.Data.load("count"), 3);
assert.equal(context.BdApi.Data.delete("ExamplePlugin", "enabled"), true);
assert.ok(toasts.some(value => String(value).includes("loaded")));

context.__plugin.stop();
assert.equal(context.BdApi, undefined);
console.log("Runtime compatibility smoke test passed");
