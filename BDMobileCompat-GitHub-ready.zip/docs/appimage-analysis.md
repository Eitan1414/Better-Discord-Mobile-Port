# Static analysis of the supplied Linux AppImage

The supplied `BetterDiscord-Linux.AppImage` was inspected without launching the BetterDiscord application.

- File type: 64-bit x86 Linux AppImage
- Size: about 76 MB
- SHA-256: `227e49e935a826c14e0c3c0c5ddd65320df7e35219243d8e25e6d5b60212c4fd`
- Embedded application: BetterDiscord Installer 1.3.0
- UI/runtime: Electron and Svelte
- Main archive: `resources/app.asar`

The archive contains the desktop installer logic and interface. It does not contain the complete current BetterDiscord runtime used inside Discord. No binary or source extracted from the AppImage is redistributed in this project.

Useful concepts retained for the mobile bridge:

- installation and repair status;
- scoped plugin settings;
- clear compatibility diagnostics;
- safe failure behavior.
