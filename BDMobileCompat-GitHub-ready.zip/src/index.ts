/*
 * BD Mobile Compat
 *
 * Experimental BetterDiscord BdApi compatibility bridge for Revenge.
 * This does not copy or bundle Discord, BetterDiscord, or Revenge code.
 */

interface CompatStorage {
    data?: Record<string, Record<string, unknown>>;
    safeMode?: boolean;
    strictUnsupported?: boolean;
    bootCount?: number;
    lastBootOk?: boolean;
}

type AnyRecord = Record<string, any>;
type Unpatcher = () => unknown;

const BRIDGE_ID = "dev.bdmobile.compat";
const BRIDGE_VERSION = "0.1.0";
const storage = bunny.plugin.createStorage() as CompatStorage;
const previousBdApiDescriptor = Object.getOwnPropertyDescriptor(globalThis, "BdApi");
const previousMobileDescriptor = Object.getOwnPropertyDescriptor(globalThis, "BDMobileCompat");
const patchesByCaller = new Map<string, Set<Unpatcher>>();
const commandDisposersByCaller = new Map<string, Set<Unpatcher>>();

function ensureStorage(): Required<CompatStorage> {
    storage.data ??= {};
    storage.safeMode ??= false;
    storage.strictUnsupported ??= false;
    storage.bootCount ??= 0;
    storage.lastBootOk ??= true;
    return storage as Required<CompatStorage>;
}

function stringifyContent(content: unknown): string {
    if (typeof content === "string") return content;
    if (content == null) return "";
    if (typeof content === "number" || typeof content === "boolean") return String(content);
    try {
        return JSON.stringify(content, null, 2);
    } catch {
        return String(content);
    }
}

function logPrefix(scope?: string): string {
    return scope ? `[BDMobile:${scope}]` : "[BDMobile]";
}

function unsupported(name: string, fallback?: any): any {
    const message = `${name} is not available on Discord Android/React Native.`;
    if (ensureStorage().strictUnsupported) throw new Error(message);
    console.warn(logPrefix("Compat"), message);
    return fallback;
}

function toDisplayAddon(id: string, manifest: AnyRecord, instance?: AnyRecord): AnyRecord {
    const display = manifest?.display ?? {};
    const authors = Array.isArray(display.authors)
        ? display.authors.map((author: AnyRecord) => author?.name).filter(Boolean)
        : [];

    return {
        id,
        name: display.name ?? id,
        author: authors.join(", "),
        authors: display.authors ?? [],
        version: manifest?.version ?? "0.0.0",
        description: display.description ?? "",
        filename: id,
        instance,
        manifest
    };
}

function resolvePluginId(idOrName: string): string | undefined {
    const manifests: Map<string, AnyRecord> | undefined = bunny.plugins?.registeredPlugins;
    if (!manifests) return undefined;
    if (manifests.has(idOrName)) return idOrName;

    const lowered = String(idOrName).toLowerCase();
    for (const [id, manifest] of manifests) {
        if (String(manifest?.display?.name ?? "").toLowerCase() === lowered) return id;
    }
    return undefined;
}

function resolveThemeId(idOrName: string): string | undefined {
    const themes: AnyRecord = bunny.themes?.themes ?? {};
    if (themes[idOrName]) return idOrName;

    const lowered = String(idOrName).toLowerCase();
    for (const [id, theme] of Object.entries(themes) as Array<[string, AnyRecord]>) {
        const name = theme?.data?.name ?? theme?.data?.display?.name ?? id;
        if (String(name).toLowerCase() === lowered) return id;
    }
    return undefined;
}

function trackDisposer(map: Map<string, Set<Unpatcher>>, caller: string, disposer: Unpatcher): Unpatcher {
    let set = map.get(caller);
    if (!set) map.set(caller, set = new Set());
    set.add(disposer);

    let active = true;
    return () => {
        if (!active) return false;
        active = false;
        set?.delete(disposer);
        if (set?.size === 0) map.delete(caller);
        return disposer();
    };
}

function disposeCaller(map: Map<string, Set<Unpatcher>>, caller: string): void {
    const disposers = map.get(caller);
    if (!disposers) return;
    map.delete(caller);
    for (const disposer of [...disposers]) {
        try { disposer(); }
        catch (error) { console.error(logPrefix(caller), "Disposer failed", error); }
    }
}

function disposeAll(map: Map<string, Set<Unpatcher>>): void {
    for (const caller of [...map.keys()]) disposeCaller(map, caller);
}

class DataApi {
    save(pluginName: string, key: string, value: unknown): void {
        const state = ensureStorage();
        state.data[pluginName] ??= {};
        state.data[pluginName][key] = value;
    }

    load<T = unknown>(pluginName: string, key: string): T | undefined {
        return ensureStorage().data[pluginName]?.[key] as T | undefined;
    }

    delete(pluginName: string, key: string): boolean {
        const pluginData = ensureStorage().data[pluginName];
        if (!pluginData || !(key in pluginData)) return false;
        delete pluginData[key];
        if (Object.keys(pluginData).length === 0) delete ensureStorage().data[pluginName];
        return true;
    }

    async recache(_pluginName: string): Promise<boolean> {
        return true;
    }
}

class BoundDataApi {
    constructor(private readonly pluginName: string) {}
    save(key: string, value: unknown): void { Data.save(this.pluginName, key, value); }
    load<T = unknown>(key: string): T | undefined { return Data.load<T>(this.pluginName, key); }
    delete(key: string): boolean { return Data.delete(this.pluginName, key); }
    recache(): Promise<boolean> { return Data.recache(this.pluginName); }
}

const Data = new DataApi();

class LoggerApi {
    log(pluginName: string, ...message: unknown[]): void { console.log(logPrefix(pluginName), ...message); }
    info(pluginName: string, ...message: unknown[]): void { console.info(logPrefix(pluginName), ...message); }
    warn(pluginName: string, ...message: unknown[]): void { console.warn(logPrefix(pluginName), ...message); }
    error(pluginName: string, ...message: unknown[]): void { console.error(logPrefix(pluginName), ...message); }
    debug(pluginName: string, ...message: unknown[]): void { console.debug(logPrefix(pluginName), ...message); }
    stacktrace(pluginName: string, message: string, error: unknown): void {
        console.error(logPrefix(pluginName), message, error);
    }
}

class BoundLoggerApi {
    constructor(private readonly pluginName: string) {}
    log(...message: unknown[]): void { Logger.log(this.pluginName, ...message); }
    info(...message: unknown[]): void { Logger.info(this.pluginName, ...message); }
    warn(...message: unknown[]): void { Logger.warn(this.pluginName, ...message); }
    error(...message: unknown[]): void { Logger.error(this.pluginName, ...message); }
    debug(...message: unknown[]): void { Logger.debug(this.pluginName, ...message); }
    stacktrace(message: string, error: unknown): void { Logger.stacktrace(this.pluginName, message, error); }
}

const Logger = new LoggerApi();

class PatcherApi {
    before(caller: string, target: AnyRecord, method: string, callback: Function): Unpatcher {
        if (ensureStorage().safeMode) return unsupported("BdApi.Patcher.before (safe mode)", () => false);
        if (!target || typeof target[method] !== "function") throw new TypeError(`Cannot patch ${method}`);

        const unpatch = bunny.api.patcher.before(method, target, (args: unknown[]) => {
            try {
                const nextArgs = callback(target, args);
                return Array.isArray(nextArgs) ? nextArgs : undefined;
            } catch (error) {
                Logger.error(caller, `before patch for ${method} failed`, error);
                return undefined;
            }
        });
        return trackDisposer(patchesByCaller, caller, unpatch);
    }

    after(caller: string, target: AnyRecord, method: string, callback: Function): Unpatcher {
        if (ensureStorage().safeMode) return unsupported("BdApi.Patcher.after (safe mode)", () => false);
        if (!target || typeof target[method] !== "function") throw new TypeError(`Cannot patch ${method}`);

        const unpatch = bunny.api.patcher.after(method, target, (args: unknown[], result: unknown) => {
            try {
                const replacement = callback(target, args, result);
                return replacement === undefined ? result : replacement;
            } catch (error) {
                Logger.error(caller, `after patch for ${method} failed`, error);
                return result;
            }
        });
        return trackDisposer(patchesByCaller, caller, unpatch);
    }

    instead(caller: string, target: AnyRecord, method: string, callback: Function): Unpatcher {
        if (ensureStorage().safeMode) return unsupported("BdApi.Patcher.instead (safe mode)", () => false);
        if (!target || typeof target[method] !== "function") throw new TypeError(`Cannot patch ${method}`);

        const unpatch = bunny.api.patcher.instead(method, target, (args: unknown[], original: Function) => {
            const callOriginal = (...nextArgs: unknown[]) => original(...(nextArgs.length ? nextArgs : args));
            try {
                return callback(target, args, callOriginal);
            } catch (error) {
                Logger.error(caller, `instead patch for ${method} failed`, error);
                return callOriginal(...args);
            }
        });
        return trackDisposer(patchesByCaller, caller, unpatch);
    }

    getPatchesByCaller(caller: string): Array<{unpatch: Unpatcher}> {
        return [...(patchesByCaller.get(caller) ?? [])].map(unpatch => ({ unpatch }));
    }

    unpatchAll(caller: string): void { disposeCaller(patchesByCaller, caller); }
}

class BoundPatcherApi {
    constructor(private readonly caller: string) {}
    before(target: AnyRecord, method: string, callback: Function): Unpatcher {
        return Patcher.before(this.caller, target, method, callback);
    }
    after(target: AnyRecord, method: string, callback: Function): Unpatcher {
        return Patcher.after(this.caller, target, method, callback);
    }
    instead(target: AnyRecord, method: string, callback: Function): Unpatcher {
        return Patcher.instead(this.caller, target, method, callback);
    }
    getPatchesByCaller(): Array<{unpatch: Unpatcher}> { return Patcher.getPatchesByCaller(this.caller); }
    unpatchAll(): void { Patcher.unpatchAll(this.caller); }
}

const Patcher = new PatcherApi();

const ReactModule = bunny.metro?.common?.React ?? (globalThis as AnyRecord).React;
const ReactNativeModule = bunny.metro?.common?.ReactNative ?? (globalThis as AnyRecord).ReactNative;

const UI = {
    showToast(content: unknown, _options: AnyRecord = {}): void {
        const message = stringifyContent(content);
        const showToast = bunny.ui?.toasts?.showToast;
        if (typeof showToast === "function") showToast(message);
        else console.info(logPrefix("Toast"), message);
    },

    alert(title: unknown, content: unknown): void {
        const nativeAlert = ReactNativeModule?.Alert?.alert;
        if (typeof nativeAlert === "function") nativeAlert(stringifyContent(title), stringifyContent(content));
        else UI.showToast(`${stringifyContent(title)}: ${stringifyContent(content)}`);
    },

    showConfirmationModal(title: unknown, content: unknown, options: AnyRecord = {}): Unpatcher {
        const nativeAlert = ReactNativeModule?.Alert?.alert;
        if (typeof nativeAlert !== "function") {
            unsupported("BdApi.UI.showConfirmationModal", undefined);
            return () => false;
        }

        nativeAlert(
            stringifyContent(title),
            stringifyContent(content),
            [
                {
                    text: options.cancelText ?? "Cancel",
                    style: "cancel",
                    onPress: () => options.onCancel?.()
                },
                {
                    text: options.confirmText ?? "Okay",
                    style: options.danger ? "destructive" : "default",
                    onPress: () => options.onConfirm?.()
                }
            ],
            {
                cancelable: true,
                onDismiss: () => options.onCancel?.()
            }
        );
        return () => false;
    },

    showNotice(content: unknown, options: AnyRecord = {}): Unpatcher {
        UI.showToast(content, options);
        return () => false;
    },

    showChangelogModal(options: AnyRecord): void {
        UI.alert(options?.title ?? "Changelog", options?.changes ?? options?.subtitle ?? "");
    }
};

const Plugins = {
    get folder(): undefined { return undefined; },

    getAll(): AnyRecord[] {
        const manifests: Map<string, AnyRecord> | undefined = bunny.plugins?.registeredPlugins;
        if (!manifests) return [];
        return [...manifests].map(([id, manifest]) =>
            toDisplayAddon(id, manifest, bunny.plugins?.pluginInstances?.get?.(id))
        );
    },

    get(idOrName: string): AnyRecord | undefined {
        const id = resolvePluginId(idOrName);
        if (!id) return undefined;
        const manifest = bunny.plugins?.registeredPlugins?.get?.(id);
        return manifest ? toDisplayAddon(id, manifest, bunny.plugins?.pluginInstances?.get?.(id)) : undefined;
    },

    isEnabled(idOrName: string): boolean {
        const id = resolvePluginId(idOrName);
        return Boolean(id && bunny.plugins?.isPluginEnabled?.(id));
    },

    enable(idOrName: string): Promise<unknown> | undefined {
        const id = resolvePluginId(idOrName);
        if (!id) return undefined;
        return bunny.plugins?.enablePlugin?.(id, true);
    },

    disable(idOrName: string): unknown {
        const id = resolvePluginId(idOrName);
        if (!id) return undefined;
        return bunny.plugins?.disablePlugin?.(id);
    },

    toggle(idOrName: string): unknown {
        return Plugins.isEnabled(idOrName) ? Plugins.disable(idOrName) : Plugins.enable(idOrName);
    },

    async reload(idOrName: string): Promise<unknown> {
        const id = resolvePluginId(idOrName);
        if (!id) return undefined;
        if (typeof bunny.plugins?.refreshPlugin === "function" && bunny.plugins?.pluginInstances?.has?.(id)) {
            return bunny.plugins.refreshPlugin(id);
        }
        if (Plugins.isEnabled(id)) {
            Plugins.disable(id);
            return Plugins.enable(id);
        }
        return undefined;
    }
};

const Themes = {
    get folder(): undefined { return undefined; },

    getAll(): AnyRecord[] {
        const themes: AnyRecord = bunny.themes?.themes ?? {};
        return Object.entries(themes).map(([id, theme]) => ({
            id,
            name: (theme as AnyRecord)?.data?.name ?? id,
            version: (theme as AnyRecord)?.data?.version ?? "0.0.0",
            description: (theme as AnyRecord)?.data?.description ?? "",
            author: (theme as AnyRecord)?.data?.author ?? "",
            filename: id,
            enabled: Boolean((theme as AnyRecord)?.selected),
            instance: theme
        }));
    },

    get(idOrName: string): AnyRecord | undefined {
        const id = resolveThemeId(idOrName);
        return id ? Themes.getAll().find(theme => theme.id === id) : undefined;
    },

    isEnabled(idOrName: string): boolean {
        const id = resolveThemeId(idOrName);
        return Boolean(id && bunny.themes?.themes?.[id]?.selected);
    },

    enable(idOrName: string): unknown {
        const id = resolveThemeId(idOrName);
        const theme = id ? bunny.themes?.themes?.[id] : undefined;
        return theme ? bunny.themes?.selectTheme?.(theme) : undefined;
    },

    disable(idOrName: string): unknown {
        return Themes.isEnabled(idOrName) ? bunny.themes?.selectTheme?.(null) : undefined;
    },

    toggle(idOrName: string): unknown {
        return Themes.isEnabled(idOrName) ? Themes.disable(idOrName) : Themes.enable(idOrName);
    },

    reload(idOrName: string): unknown {
        const id = resolveThemeId(idOrName);
        const theme = id ? bunny.themes?.themes?.[id] : undefined;
        return theme && theme.selected ? bunny.themes?.selectTheme?.(theme) : undefined;
    }
};

function metroFilter(filter: Function): Function {
    const wrapped = (moduleExports: unknown, moduleId?: number, defaultExport?: boolean) => {
        try { return Boolean(filter(moduleExports, moduleId, defaultExport)); }
        catch { return false; }
    };
    (wrapped as AnyRecord).uniq = false;
    (wrapped as AnyRecord).raw = false;
    return wrapped;
}

const WebpackFilters = {
    byKeys: (...keys: string[]) => bunny.metro?.filters?.byProps?.(...keys) ?? metroFilter((module: AnyRecord) => keys.every(key => key in (module ?? {}))),
    byPrototypeKeys: (...keys: string[]) => metroFilter((module: AnyRecord) => keys.every(key => key in (module?.prototype ?? {}))),
    byDisplayName: (name: string) => bunny.metro?.filters?.byDisplayName?.(name) ?? metroFilter((module: AnyRecord) => module?.displayName === name),
    byStrings: (...strings: string[]) => metroFilter((module: unknown) => {
        const source = typeof module === "function" ? Function.prototype.toString.call(module) : "";
        return strings.every(value => source.includes(value));
    }),
    byRegex: (regex: RegExp) => metroFilter((module: unknown) => typeof module === "function" && regex.test(Function.prototype.toString.call(module))),
    combine: (...filters: Function[]) => metroFilter((module: unknown, id?: number, defaultExport?: boolean) => filters.every(filter => filter(module, id, defaultExport)))
};

const Webpack = {
    Filters: WebpackFilters,

    getModule(filter: Function, _options: AnyRecord = {}): any {
        if (ensureStorage().safeMode) return unsupported("BdApi.Webpack.getModule (safe mode)", undefined);
        try { return bunny.metro?.findExports?.(metroFilter(filter)); }
        catch (error) {
            Logger.error("Webpack", "getModule failed", error);
            return undefined;
        }
    },

    getModules(filter: Function): any[] {
        if (ensureStorage().safeMode) return unsupported("BdApi.Webpack.getModules (safe mode)", []);
        try { return bunny.metro?.findAllExports?.(metroFilter(filter))?.filter(Boolean) ?? []; }
        catch (error) {
            Logger.error("Webpack", "getModules failed", error);
            return [];
        }
    },

    getByKeys(...keys: string[]): any {
        if (ensureStorage().safeMode) return unsupported("BdApi.Webpack.getByKeys (safe mode)", undefined);
        return bunny.metro?.findByProps?.(...keys) ?? Webpack.getModule((module: AnyRecord) => keys.every(key => key in (module ?? {})));
    },

    getByPrototypeKeys(...keys: string[]): any {
        return Webpack.getModule((module: AnyRecord) => keys.every(key => key in (module?.prototype ?? {})));
    },

    getByDisplayName(name: string): any {
        if (ensureStorage().safeMode) return unsupported("BdApi.Webpack.getByDisplayName (safe mode)", undefined);
        return bunny.metro?.findByDisplayName?.(name) ?? Webpack.getModule((module: AnyRecord) => module?.displayName === name);
    },

    getByStrings(...strings: string[]): any {
        return Webpack.getModule(WebpackFilters.byStrings(...strings));
    },

    getStore(name: string): any {
        if (ensureStorage().safeMode) return unsupported("BdApi.Webpack.getStore (safe mode)", undefined);
        return bunny.metro?.findByStoreName?.(name);
    },

    async waitForModule(filter: Function, options: AnyRecord = {}): Promise<any> {
        const timeout = Number(options.timeout ?? 10_000);
        const interval = Number(options.interval ?? 100);
        const started = Date.now();
        while (Date.now() - started < timeout) {
            const found = Webpack.getModule(filter, options);
            if (found !== undefined) return found;
            await new Promise(resolve => setTimeout(resolve, interval));
        }
        return undefined;
    }
};

const Utils = {
    findInTree(tree: any, filter: (value: any) => boolean, options: AnyRecord = {}): any {
        const walkable = options.walkable as string[] | undefined;
        const ignore = new Set(options.ignore ?? []);
        const seen = new Set<any>();

        const visit = (value: any): any => {
            if (value == null || (typeof value !== "object" && typeof value !== "function")) return undefined;
            if (seen.has(value)) return undefined;
            seen.add(value);
            if (filter(value)) return value;

            const keys = walkable ?? Object.keys(value);
            for (const key of keys) {
                if (ignore.has(key)) continue;
                let child: any;
                try { child = value[key]; }
                catch { continue; }
                const found = visit(child);
                if (found !== undefined) return found;
            }
            return undefined;
        };
        return visit(tree);
    },

    findInReactTree(tree: any, filter: (value: any) => boolean): any {
        return Utils.findInTree(tree, filter, { walkable: ["props", "children", "child", "sibling"] });
    },

    getNestedValue(object: AnyRecord, path: string | string[]): any {
        const parts = Array.isArray(path) ? path : String(path).split(".");
        return parts.reduce((value, key) => value?.[key], object);
    },

    debounce<T extends (...args: any[]) => any>(callback: T, delay: number): T {
        let timer: any;
        return function(this: any, ...args: any[]) {
            clearTimeout(timer);
            timer = setTimeout(() => callback.apply(this, args), delay);
        } as T;
    },

    throttle<T extends (...args: any[]) => any>(callback: T, delay: number): T {
        let last = 0;
        let pending: any;
        return function(this: any, ...args: any[]) {
            const now = Date.now();
            const remaining = delay - (now - last);
            if (remaining <= 0) {
                clearTimeout(pending);
                last = now;
                return callback.apply(this, args);
            }
            clearTimeout(pending);
            pending = setTimeout(() => {
                last = Date.now();
                callback.apply(this, args);
            }, remaining);
        } as T;
    },

    className(...values: Array<string | false | null | undefined>): string {
        return values.filter(Boolean).join(" ");
    },

    escapeHTML(value: unknown): string {
        return stringifyContent(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }
};

const DOM = {
    addStyle(_id: string, _css: string): void { unsupported("BdApi.DOM.addStyle"); },
    removeStyle(_id: string): void { unsupported("BdApi.DOM.removeStyle"); },
    createElement(): undefined { return unsupported("BdApi.DOM.createElement", undefined); },
    parseHTML(): undefined { return unsupported("BdApi.DOM.parseHTML", undefined); }
};

const ReactUtils = {
    findInTree: Utils.findInTree,
    findInReactTree: Utils.findInReactTree,
    getInternalInstance(): undefined { return unsupported("BdApi.ReactUtils.getInternalInstance", undefined); },
    getOwnerInstance(): undefined { return unsupported("BdApi.ReactUtils.getOwnerInstance", undefined); }
};

const ContextMenu = {
    patch(): Unpatcher { return unsupported("BdApi.ContextMenu.patch", () => false); },
    unpatch(): void { unsupported("BdApi.ContextMenu.unpatch"); },
    open(): void { unsupported("BdApi.ContextMenu.open"); },
    close(): void { unsupported("BdApi.ContextMenu.close"); }
};

const Net = {
    fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
        return globalThis.fetch(input, init);
    }
};

class CommandsApi {
    register(caller: string, command: AnyRecord): Unpatcher {
        const register = bunny.api?.commands?.registerCommand;
        if (typeof register !== "function") return unsupported("BdApi.Commands.register", () => false);
        const disposer = register(command);
        return trackDisposer(commandDisposersByCaller, caller, disposer);
    }
    unregisterAll(caller: string): void { disposeCaller(commandDisposersByCaller, caller); }
}

class BoundCommandsApi {
    constructor(private readonly caller: string) {}
    register(command: AnyRecord): Unpatcher { return Commands.register(this.caller, command); }
    unregisterAll(): void { Commands.unregisterAll(this.caller); }
}

const Commands = new CommandsApi();
const scopedApis = new Map<string, BdApiCompat>();

class BdApiCompat {
    static version = `${BRIDGE_VERSION}-android`;
    static React = ReactModule;
    static ReactDOM = undefined;
    static Components = bunny.ui?.components ?? {};
    static Net = Net;
    static Webpack = Webpack;
    static Plugins = Plugins;
    static Themes = Themes;
    static Utils = Utils;
    static UI = UI;
    static ReactUtils = ReactUtils;
    static ContextMenu = ContextMenu;
    static Patcher = Patcher;
    static Data = Data;
    static DOM = DOM;
    static Logger = Logger;
    static Commands = Commands;
    static Hooks = {};
    static ReactNative = ReactNativeModule;
    static mobile = true;

    private readonly pluginName!: string;

    constructor(pluginName?: string) {
        const resolvedName = typeof pluginName === "string" && pluginName.length > 0
            ? pluginName
            : "UnknownPlugin";
        const cached = scopedApis.get(resolvedName);
        if (cached) return cached;

        this.pluginName = resolvedName;
        scopedApis.set(resolvedName, this);
    }

    get version(): string { return BdApiCompat.version; }
    get React(): any { return BdApiCompat.React; }
    get ReactDOM(): undefined { return undefined; }
    get ReactNative(): any { return ReactNativeModule; }
    get Components(): AnyRecord { return BdApiCompat.Components; }
    get Net(): AnyRecord { return Net; }
    get Webpack(): AnyRecord { return Webpack; }
    get Plugins(): AnyRecord { return Plugins; }
    get Themes(): AnyRecord { return Themes; }
    get Utils(): AnyRecord { return Utils; }
    get UI(): AnyRecord { return UI; }
    get ReactUtils(): AnyRecord { return ReactUtils; }
    get ContextMenu(): AnyRecord { return ContextMenu; }
    get DOM(): AnyRecord { return DOM; }
    get Hooks(): AnyRecord { return {}; }
    get Patcher(): BoundPatcherApi { return new BoundPatcherApi(this.pluginName); }
    get Data(): BoundDataApi { return new BoundDataApi(this.pluginName); }
    get Logger(): BoundLoggerApi { return new BoundLoggerApi(this.pluginName); }
    get Commands(): BoundCommandsApi { return new BoundCommandsApi(this.pluginName); }
}

function installGlobals(): void {
    Object.defineProperty(globalThis, "BdApi", {
        configurable: true,
        enumerable: false,
        writable: true,
        value: BdApiCompat
    });

    Object.defineProperty(globalThis, "BDMobileCompat", {
        configurable: true,
        enumerable: false,
        writable: false,
        value: {
            id: BRIDGE_ID,
            version: BRIDGE_VERSION,
            platform: "android",
            runtime: "revenge",
            get safeMode() { return ensureStorage().safeMode; },
            get strictUnsupported() { return ensureStorage().strictUnsupported; },
            compatibility: {
                Data: "supported",
                Logger: "supported",
                UI: "partial",
                Patcher: "adapted",
                Plugins: "adapted",
                Themes: "native-theme-only",
                Webpack: "best-effort-metro",
                DOM: "unsupported",
                ReactDOM: "unsupported",
                Electron: "unsupported",
                CSS: "unsupported"
            }
        }
    });
}

function restoreDescriptor(name: string, descriptor?: PropertyDescriptor): void {
    try {
        if (descriptor) Object.defineProperty(globalThis, name, descriptor);
        else delete (globalThis as AnyRecord)[name];
    } catch (error) {
        console.error(logPrefix("Compat"), `Unable to restore ${name}`, error);
    }
}

function SettingsComponent(): any {
    if (!ReactModule?.createElement || !ReactNativeModule) return null;
    const React = ReactModule;
    const RN = ReactNativeModule;
    const state = ensureStorage();
    const [, refresh] = React.useReducer((value: number) => value + 1, 0);

    const setFlag = (key: "safeMode" | "strictUnsupported", value: boolean) => {
        state[key] = value;
        refresh();
        UI.showToast("Setting saved. Restart Discord to fully apply it.");
    };

    const row = (label: string, value: string) => React.createElement(
        RN.View,
        { style: styles.row, key: label },
        React.createElement(RN.Text, { style: styles.label }, label),
        React.createElement(RN.Text, { style: styles.value }, value)
    );

    return React.createElement(
        RN.ScrollView,
        { style: styles.container, contentContainerStyle: styles.content },
        React.createElement(RN.Text, { style: styles.title }, "BD Mobile Compat"),
        React.createElement(
            RN.Text,
            { style: styles.description },
            "Experimental BdApi bridge for BetterDiscord-style plugins on Revenge. Desktop CSS, DOM and Electron APIs cannot run on mobile."
        ),
        React.createElement(
            RN.View,
            { style: styles.switchRow },
            React.createElement(
                RN.View,
                { style: styles.switchText },
                React.createElement(RN.Text, { style: styles.label }, "Safe mode"),
                React.createElement(RN.Text, { style: styles.help }, "Disables Patcher and Metro/Webpack compatibility.")
            ),
            React.createElement(RN.Switch, {
                value: state.safeMode,
                onValueChange: (value: boolean) => setFlag("safeMode", value)
            })
        ),
        React.createElement(
            RN.View,
            { style: styles.switchRow },
            React.createElement(
                RN.View,
                { style: styles.switchText },
                React.createElement(RN.Text, { style: styles.label }, "Strict unsupported APIs"),
                React.createElement(RN.Text, { style: styles.help }, "Throws an error instead of returning a safe fallback.")
            ),
            React.createElement(RN.Switch, {
                value: state.strictUnsupported,
                onValueChange: (value: boolean) => setFlag("strictUnsupported", value)
            })
        ),
        React.createElement(RN.Text, { style: styles.section }, "Compatibility"),
        row("Data / Logger", "Supported"),
        row("UI", "Partial, native dialogs"),
        row("Patcher", "Adapted to Revenge"),
        row("Plugins", "Revenge plugins"),
        row("Themes", "Native JSON themes"),
        row("Webpack", "Best effort via Metro"),
        row("DOM / CSS / Electron", "Unsupported"),
        React.createElement(
            RN.Pressable,
            {
                style: styles.button,
                onPress: () => UI.showToast(`BdApi ${BdApiCompat.version} is active`)
            },
            React.createElement(RN.Text, { style: styles.buttonText }, "Run diagnostic toast")
        ),
        React.createElement(
            RN.Pressable,
            {
                style: [styles.button, styles.dangerButton],
                onPress: () => UI.showConfirmationModal(
                    "Reset compatibility data?",
                    "This clears values saved through BdApi.Data. BetterDiscord plugins may lose their settings.",
                    {
                        danger: true,
                        confirmText: "Reset",
                        onConfirm: () => {
                            state.data = {};
                            refresh();
                            UI.showToast("Compatibility data cleared");
                        }
                    }
                )
            },
            React.createElement(RN.Text, { style: styles.buttonText }, "Reset BdApi.Data")
        )
    );
}

const styles = ReactNativeModule?.StyleSheet?.create?.({
    container: { flex: 1 },
    content: { padding: 16, gap: 12 },
    title: { fontSize: 24, fontWeight: "700", color: "white" },
    description: { fontSize: 14, lineHeight: 20, opacity: 0.8, color: "white" },
    section: { marginTop: 12, fontSize: 17, fontWeight: "700", color: "white" },
    row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 7 },
    switchRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 8 },
    switchText: { flex: 1, paddingRight: 12 },
    label: { fontSize: 15, fontWeight: "600", color: "white" },
    value: { fontSize: 13, opacity: 0.7, color: "white", textAlign: "right", maxWidth: "55%" },
    help: { fontSize: 12, opacity: 0.65, color: "white", marginTop: 3 },
    button: { padding: 13, borderRadius: 8, backgroundColor: "#5865F2", alignItems: "center", marginTop: 8 },
    dangerButton: { backgroundColor: "#DA373C" },
    buttonText: { color: "white", fontWeight: "700" }
}) ?? {};

const define = typeof definePlugin === "function" ? definePlugin : <T extends object>(value: T) => value;

const plugin = define({
    start(): void {
        const state = ensureStorage();
        state.bootCount += 1;
        state.lastBootOk = false;
        installGlobals();
        state.lastBootOk = true;
        UI.showToast(`BD Mobile Compat ${BRIDGE_VERSION} loaded${state.safeMode ? " in safe mode" : ""}`);
    },

    stop(): void {
        disposeAll(patchesByCaller);
        disposeAll(commandDisposersByCaller);
        scopedApis.clear();
        restoreDescriptor("BdApi", previousBdApiDescriptor);
        restoreDescriptor("BDMobileCompat", previousMobileDescriptor);
    },

    SettingsComponent
});
