declare const bunny: any;
declare const definePlugin: undefined | (<T extends object>(plugin: T) => T);
