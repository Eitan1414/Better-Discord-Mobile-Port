import {copyFileSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync} from "node:fs";
import {spawnSync} from "node:child_process";
import {join} from "node:path";
import process from "node:process";

const root = process.cwd();
const packageJson = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const manifest = JSON.parse(readFileSync(join(root, "manifest.template.json"), "utf8"));
manifest.version = packageJson.version;
const pluginId = manifest.id;

rmSync(join(root, "dist"), {recursive: true, force: true});
rmSync(join(root, "builds"), {recursive: true, force: true});

const localTsc = join(root, "node_modules", ".bin", process.platform === "win32" ? "tsc.cmd" : "tsc");
const tsc = existsSync(localTsc) ? localTsc : (process.platform === "win32" ? "tsc.cmd" : "tsc");
const result = spawnSync(tsc, ["-p", "tsconfig.json"], {cwd: root, stdio: "inherit"});
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);

const buildDir = join(root, "builds", pluginId);
mkdirSync(buildDir, {recursive: true});
copyFileSync(join(root, "dist", "index.js"), join(buildDir, "index.js"));
writeFileSync(join(buildDir, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);

const repository = {
    $meta: {
        name: "BD Mobile Compat",
        description: "Experimental BetterDiscord compatibility for Discord Android through Revenge."
    },
    [pluginId]: {
        version: packageJson.version
    }
};
writeFileSync(join(root, "repo.json"), `${JSON.stringify(repository, null, 2)}\n`);
console.log(`Built ${pluginId} ${packageJson.version}`);
